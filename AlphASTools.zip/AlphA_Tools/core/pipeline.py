"""
core/pipeline.py — Connects GUI with the lua generation, OST injection, and Steam restart.
"""

import os
import shutil
import subprocess
from pathlib import Path
from .lua_gen import LuaGenerator  # Artık core içinden import ediyoruz

# Paths
_HERE = Path(__file__).parent.resolve()
_BASE_DIR = _HERE.parent
_DATA_DIR = _BASE_DIR / "data"
_OST_DATA_DIR = _DATA_DIR / "ost"

STEAM_DIR = Path(os.path.expandvars(r"%ProgramFiles(x86)%\Steam"))
STEAM_CONFIG_DIR = STEAM_DIR / "config" / "stplug-in"

def handle_app(app_id: str, gui=None):
    def log(msg, level="info"):
        if gui:
            if level == "info": gui.log_info(msg, tag="pipe")
            elif level == "ok": gui.log_ok(msg, tag="pipe")
            elif level == "err": gui.log_err(msg, tag="pipe")
            elif level == "warn": gui.log_warn(msg, tag="pipe")
            elif level == "debug": gui.log_debug(msg, tag="pipe")
        else:
            print(f"[{level.upper()}] {msg}")

    log(f"Starting pipeline for {app_id}")
    if gui:
        gui.set_status("processing", "#F59E0B")
        gui.set_progress(0.1)

    try:
        # 1. Generate Lua
        gen = LuaGenerator()
        lua_file = gen.generate(app_id)
        if not lua_file.exists():
            log("Failed to generate lua", "err")
            return
        log(f"Lua generated: {lua_file.name}", "ok")
        
        # 2. Inject into Steam config
        if not STEAM_CONFIG_DIR.exists():
            log("Steam config directory not found.", "err")
            return
        shutil.copy2(lua_file, STEAM_CONFIG_DIR / f"{app_id}.lua")
        log(f"Injected {app_id}.lua into Steam config", "ok")
        if gui: gui.set_progress(0.5)

        # 3. Copy OST DLLs to Steam root
        if _OST_DATA_DIR.exists():
            for dll_name in ["dwmapi.dll", "xinput1_4.dll", "OpenSteamTool.dll", "version.dll", "winmm.dll"]:
                target = STEAM_DIR / dll_name
                if target.exists():
                    try: os.remove(target)
                    except: pass

            copied = 0
            for file in _OST_DATA_DIR.iterdir():
                if file.is_file() and file.suffix == ".dll":
                    try:
                        shutil.copy2(file, STEAM_DIR / file.name)
                        copied += 1
                    except Exception as e:
                        log(f"Failed to copy {file.name}: {e}", "warn")
            
            if copied > 0:
                log(f"Injected {copied} BetterSteamTools DLLs to Steam root.", "ok")
        if gui: gui.set_progress(0.7)

        # 4. Start Steam
        steam_cfg = STEAM_DIR / "steam.cfg"
        if steam_cfg.exists():
            try: os.remove(steam_cfg)
            except: pass

        steam_exe = STEAM_DIR / "steam.exe"
        if steam_exe.exists():
            log("Starting Steam with BetterSteamTools...")
            subprocess.Popen([str(steam_exe)], creationflags=0x00000008)
            log("Steam starting up.", "ok")
        else:
            log("steam.exe not found.", "err")
            
        if gui: 
            gui.set_progress(1.0)
            gui.set_status("done", "#22C55E")

    except Exception as e:
        log(f"Pipeline Error: {e}", "err")
        if gui: gui.set_status("error", "#EF4444")