"""
core/lua_gen.py — Generates OpenSteamTool compatible .lua files.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import List, Dict

# Paths
_HERE = Path(__file__).parent.resolve()
_BASE_DIR = _HERE.parent
_DATA_DIR = _BASE_DIR / "data"
_LUA_DIR = _BASE_DIR / "data" / "lua_out"  # Lua çıktıları da data altında dursun

_LUA_DIR.mkdir(parents=True, exist_ok=True)

class LuaGenerator:
    def __init__(self):
        self.app_tokens = self._load("appaccesstokens.json")
        self.manifest_tokens = self._load("manifest_tokens.json")
        self.depot_keys = self._load("depotkeys.json")

    def _load(self, filename: str) -> Dict[str, str]:
        path = _DATA_DIR / filename
        if not path.exists():
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def generate(self, app_id: str) -> Path:
        lines: List[str] = []
        lines.append(f"addappid({app_id})")

        # 1. Ana app_id'ye ait veriler
        self._append_depot_data(lines, app_id)
        
        # 2. Brute-force: app_id + 1 ile app_id + 30 arasına bak
        try:
            base_id = int(app_id)
            for offset in range(1, 30):
                depot_id = str(base_id + offset)
                self._append_depot_data(lines, depot_id)
        except ValueError:
            pass

        out_path = _LUA_DIR / f"{app_id}.lua"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        
        return out_path

    def _append_depot_data(self, lines: List[str], depot_id: str):
        d_key = self.depot_keys.get(depot_id)
        d_manifest = self.manifest_tokens.get(depot_id)
        d_token = self.app_tokens.get(depot_id)

        if d_token:
            lines.append(f'addtoken({depot_id}, "{d_token}")')
        if d_key:
            lines.append(f'addappid({depot_id}, 0, "{d_key}")')
        if d_manifest:
            lines.append(f'setManifestid({depot_id}, "{d_manifest}")')