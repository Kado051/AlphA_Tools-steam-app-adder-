"""
GUI/gui.py — Steam App Adder (Canvas-based True Glassmorphism)
"""

from __future__ import annotations

import queue
import threading
import time
import urllib.request
import json
import os
import subprocess
from datetime import datetime
from typing import Callable, Optional

import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk, ImageSequence, ImageFilter, ImageDraw

# ─────────────────────────────────────────────────────────────────────────────
# Theme constants
# ─────────────────────────────────────────────────────────────────────────────
BG_ROOT      = "#000000"  
FG_TEXT      = "#FFFFFF"
FG_MUTED     = "#A0A0B0"
FG_DIM       = "#5A5A72"
ACCENT       = "#FFFFFF"  
ACCENT_HOVER = "#CCCCCC"
ACCENT_SOFT  = "#222222"

SUCCESS = "#22C55E"
WARN    = "#F59E0B"
ERROR   = "#EF4444"
INFO    = "#38BDF8"

# ── fonts ────────────────────────────────────────────────────────────────────
FONT_UI       = ("Segoe UI", 10)
FONT_H1       = ("Segoe UI Semibold", 26)
FONT_SUB      = ("Segoe UI", 10)
FONT_SECTION  = ("Segoe UI Semibold", 9)
FONT_MONO     = ("Cascadia Mono", 10)
FONT_MONO_SM  = ("Cascadia Mono", 9)
FONT_INPUT    = ("Segoe UI", 15)
FONT_BTN      = ("Segoe UI Semibold", 11)


class LogBus:
    def __init__(self) -> None:
        self._q: "queue.Queue[tuple[str, str, str]]" = queue.Queue()
    def _put(self, lvl: str, msg: str, tag: str) -> None: self._q.put((lvl, msg, tag))
    def info(self, msg, tag=""):  self._put("info",  msg, tag)
    def ok(self, msg, tag=""):    self._put("ok",    msg, tag)
    def warn(self, msg, tag=""):  self._put("warn",  msg, tag)
    def err(self, msg, tag=""):   self._put("error", msg, tag)
    def debug(self, msg, tag=""): self._put("debug", msg, tag)
    def drain(self):
        out = []
        while True:
            try: out.append(self._q.get_nowait())
            except queue.Empty: break
        return out


class SteamAppAdderGUI(tk.Tk):
    LEVEL_COLOR = {"info": INFO, "ok": SUCCESS, "warn": WARN, "error": ERROR, "debug": FG_DIM}
    LEVEL_TAG_TEXT = {"info": "INFO", "ok": " OK ", "warn": "WARN", "error": "ERR ", "debug": "DBG "}

    def __init__(self, on_submit: Optional[Callable[[str], None]] = None) -> None:
        super().__init__()
        self._on_submit = on_submit
        self._bus = LogBus()
        self._busy = False
        self._tick_id: Optional[str] = None
        self._gif_frames = []
        self._gif_durations = []
        self._gif_pils = []
        self._gif_index = 0
        
        self._panel_rects = [
            (28, 26, 994, 100, 20),   # Top Bar
            (28, 140, 994, 150, 16),  # Input Card
            (28, 310, 994, 380, 16),  # Log Panel
        ]
        
        self._small_panel_rects = [
            (28 + 994 - 320, 26 + 30, 280, 35, 8), # Statüler kutusu
            (28 + 820, 310 + 8, 50, 25, 6),        # Log Clear
            (28 + 800, 140 + 45, 80, 35, 6),       # Input Clear
            (28 + 695, 310 + 8, 100, 25, 6),       # auto-scroll
        ]
        self._blur_images = {}
        self._status_pills = {} 
        self._auto_scroll_var = tk.BooleanVar(value=True)
        self._icon_img = None # GC için

        self.title("Steam App Adder")
        self.configure(bg=BG_ROOT)
        self.geometry("1050x720")
        self.minsize(900, 600)

        self.update_idletasks()
        w, h = 1050, 720
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 3
        self.geometry(f"{w}x{h}+{x}+{y}")

        self.bg_canvas = tk.Canvas(self, bg=BG_ROOT, highlightthickness=0)
        self.bg_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        
        self._load_gif_background()
        self._setup_ttk()
        self._build_ui()
        self._bind_keys()
        self._start_pump()

        self._bus.info("Steam App Adder initialized.", tag="boot")
        self._bus.info("Enter an App ID and press Add to begin.", tag="hint")
        threading.Thread(target=self._kill_steam_on_startup, daemon=True).start()

    def _load_gif_background(self):
        gif_path = os.path.join(os.path.dirname(__file__), "bg.gif")
        if not os.path.exists(gif_path):
            self.bg_canvas.create_rectangle(0, 0, 2000, 2000, fill=BG_ROOT, tags="bg_rect")
            self.bg_canvas.create_text(525, 360, text="bg.gif not found", fill=FG_DIM, font=FONT_MONO)
            return
        try:
            img = Image.open(gif_path)
            for frame in ImageSequence.Iterator(img):
                frame_image = frame.convert("RGBA").resize((1050, 720), Image.Resampling.LANCZOS)
                self._gif_pils.append(frame_image)
                self._gif_frames.append(ImageTk.PhotoImage(frame_image))
                duration = frame.info.get('duration', 50)
                if duration == 0: duration = 50
                self._gif_durations.append(duration)

            self.bg_canvas.create_image(0, 0, image=self._gif_frames[0], anchor="nw", tags="bg_img")
            self._animate_gif()
        except Exception as e:
            self.bg_canvas.create_text(525, 360, text=f"GIF Error: {e}", fill=ERROR, font=FONT_MONO)

    def _animate_gif(self):
        if not self._gif_frames: return
        self._gif_index = (self._gif_index + 1) % len(self._gif_frames)
        
        self.bg_canvas.itemconfig("bg_img", image=self._gif_frames[self._gif_index])
        self._draw_blurred_panels()

        delay = self._gif_durations[self._gif_index]
        self.after(delay, self._animate_gif)

    def _draw_blurred_panels(self):
        current_pil = self._gif_pils[self._gif_index]
        self.bg_canvas.delete("panel_blur")
        
        all_panels = self._panel_rects + self._small_panel_rects
        
        for i, (x, y, w, h, r) in enumerate(all_panels):
            try:
                crop = current_pil.crop((x, y, x + w, y + h))
                blurred = crop.filter(ImageFilter.GaussianBlur(radius=15))
                
                mask = Image.new("L", (w, h), 0)
                draw = ImageDraw.Draw(mask)
                draw.rounded_rectangle((0, 0, w, h), radius=r, fill=255)
                
                overlay = Image.new("RGBA", blurred.size, (0, 0, 0, 60))
                final_img = Image.alpha_composite(blurred, overlay)
                final_img.putalpha(mask)
                
                tk_img = ImageTk.PhotoImage(final_img)
                
                self.bg_canvas.create_image(x, y, image=tk_img, anchor="nw", tags="panel_blur")
                self._blur_images[i] = tk_img
                
                self.bg_canvas.tag_lower("bg_img")
                self.bg_canvas.tag_raise("panel_blur", "bg_img")
                self.bg_canvas.tag_raise("widgets", "panel_blur")
                self.bg_canvas.tag_raise("texts", "widgets")
            except Exception:
                pass

    def _kill_steam_on_startup(self) -> None:
        self._bus.info("Checking for running Steam processes...", tag="boot")
        try:
            creationflags = 0x08000000 if os.name == 'nt' else 0
            result = subprocess.run(["taskkill", "/F", "/T", "/IM", "steam.exe"], capture_output=True, text=True, creationflags=creationflags)
            if "SUCCESS" in result.stdout.upper() or "BAŞARILI" in result.stdout.upper():
                self._bus.ok("Steam was closed successfully.", tag="boot")
                time.sleep(1)
            else:
                self._bus.info("Steam is not running.", tag="boot")
        except Exception as e:
            self._bus.warn(f"Could not close Steam: {e}", tag="boot")

    def _setup_ttk(self) -> None:
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure(".", background=BG_ROOT, foreground=FG_TEXT, fieldbackground=BG_ROOT, bordercolor=BG_ROOT, lightcolor=BG_ROOT, darkcolor=BG_ROOT, troughcolor=BG_ROOT, focuscolor=ACCENT, font=FONT_UI)
        style.configure("Vertical.TScrollbar", background=BG_ROOT, troughcolor=BG_ROOT, bordercolor=BG_ROOT, arrowcolor=FG_MUTED)
        style.map("Vertical.TScrollbar", background=[("active", ACCENT_SOFT)])
        style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor=BG_ROOT, bordercolor=BG_ROOT, lightcolor=ACCENT, darkcolor=ACCENT)

    def _build_ui(self) -> None:
        # ── TOP BAR ──
        x, y, w, h, r = self._panel_rects[0]
        
        # 1. ICON EKLEME KISMI
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        if os.path.exists(icon_path):
            try:
                pil_icon = Image.open(icon_path).convert("RGBA").resize((64, 64), Image.Resampling.LANCZOS)
                self._icon_img = ImageTk.PhotoImage(pil_icon)
                self.bg_canvas.create_image(x + 20, y + 18, image=self._icon_img, anchor="nw", tags="texts")
                txt_x_offset = x + 95
            except Exception as e:
                print(f"Icon error: {e}")
                txt_x_offset = x + 20
        else:
            txt_x_offset = x + 20

        # 2. YAZILAR (İkona göre kaydırıldı)
        self.bg_canvas.create_text(txt_x_offset, y + 20, text="Steam", fill=FG_TEXT, font=FONT_H1, anchor="nw", tags="texts")
        self.bg_canvas.create_text(txt_x_offset + 105, y + 20, text="App Adder", fill=ACCENT, font=FONT_H1, anchor="nw", tags="texts")
        self.bg_canvas.create_text(txt_x_offset, y + 65, text="Inject apps, depots and manifests into your Steam library", fill=FG_MUTED, font=FONT_SUB, anchor="nw", tags="texts")

        # Statüler (Genişletilmiş ve düzenli)
        px = x + w - 320
        py = y + 40
        
        self._status_pills["status_lbl"] = self.bg_canvas.create_text(px, py, text="STATUS", fill=FG_DIM, font=("Segoe UI Semibold", 8), anchor="nw", tags="texts")
        self._status_pills["status_val"] = self.bg_canvas.create_text(px + 45, py, text="idle", fill=FG_MUTED, font=("Cascadia Mono", 9, "bold"), anchor="nw", tags="texts")
        
        self._status_pills["app_lbl"] = self.bg_canvas.create_text(px + 100, py, text="APP", fill=FG_DIM, font=("Segoe UI Semibold", 8), anchor="nw", tags="texts")
        self._status_pills["app_val"] = self.bg_canvas.create_text(px + 130, py, text="—", fill=FG_MUTED, font=("Cascadia Mono", 9, "bold"), anchor="nw", tags="texts", width=120)
        
        self._status_pills["dep_lbl"] = self.bg_canvas.create_text(px + 260, py, text="DEPOTS", fill=FG_DIM, font=("Segoe UI Semibold", 8), anchor="nw", tags="texts")
        self._status_pills["dep_val"] = self.bg_canvas.create_text(px + 305, py, text="—", fill=FG_MUTED, font=("Cascadia Mono", 9, "bold"), anchor="nw", tags="texts")

        # ── INPUT CARD ──
        x, y, w, h, r = self._panel_rects[1]
        self.bg_canvas.create_text(x + 20, y + 15, text="APPLICATION ID", fill=FG_MUTED, font=FONT_SECTION, anchor="nw", tags="texts")
        
        self.entry_var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.entry_var, bg="#1A1A24", fg=FG_TEXT, insertbackground=ACCENT, relief="flat", bd=0, font=FONT_INPUT, highlightthickness=1, highlightbackground=ACCENT_SOFT, highlightcolor=ACCENT)
        self.bg_canvas.create_window(x + 20, y + 45, window=self.entry, anchor="nw", width=650, height=45, tags="widgets")
        
        self.bg_canvas.create_text(x + 710, y + 65, text="Add", fill=ACCENT, font=FONT_BTN, anchor="nw", tags=("texts", "btn_add"))
        self.bg_canvas.tag_bind("btn_add", "<Button-1>", lambda e: self._submit())
        
        self.bg_canvas.create_text(x + 820, y + 65, text="Clear", fill=FG_TEXT, font=FONT_BTN, anchor="nw", tags=("texts", "btn_clear"))
        self.bg_canvas.tag_bind("btn_clear", "<Button-1>", lambda e: self._clear())

        self.progress = ttk.Progressbar(self, orient="horizontal", mode="determinate", style="Horizontal.TProgressbar", maximum=100)
        self.bg_canvas.create_window(x + 20, y + 105, window=self.progress, anchor="nw", width=954, height=10, tags="widgets")

        # ── LOG PANEL ──
        x, y, w, h, r = self._panel_rects[2]
        self.bg_canvas.create_text(x + 16, y + 12, text="CONSOLE OUTPUT", fill=FG_MUTED, font=FONT_SECTION, anchor="nw", tags="texts")

        self._text = tk.Text(self, bg="#1A1A24", fg=FG_TEXT, insertbackground=ACCENT, relief="flat", bd=0, font=FONT_MONO, wrap="word", padx=10, pady=10, highlightthickness=0, selectbackground=ACCENT_SOFT)
        self.bg_canvas.create_window(x + 14, y + 40, window=self._text, anchor="nw", width=940, height=325, tags="widgets")
        
        for lvl, col in self.LEVEL_COLOR.items():
            self._text.tag_configure(lvl, foreground=col)
        self._text.configure(state="disabled")

        ax, ay = x + 700, y + 10
        self.bg_canvas.create_rectangle(ax, ay + 2, ax + 12, ay + 14, outline=FG_MUTED, fill=BG_ROOT, tags=("texts", "chk_box"))
        self.bg_canvas.create_text(ax + 20, ay, text="auto-scroll", fill=FG_MUTED, font=("Segoe UI", 9), anchor="nw", tags=("texts", "chk_text"))
        
        def toggle_autoscroll(e):
            val = not self._auto_scroll_var.get()
            self._auto_scroll_var.set(val)
            self.bg_canvas.itemconfig("chk_box", fill=ACCENT if val else BG_ROOT, outline=ACCENT if val else FG_MUTED)
        self.bg_canvas.tag_bind("chk_box", "<Button-1>", toggle_autoscroll)
        self.bg_canvas.tag_bind("chk_text", "<Button-1>", toggle_autoscroll)

        self.bg_canvas.create_text(x + 830, y + 10, text="Clear", fill=FG_TEXT, font=FONT_MONO_SM, anchor="nw", tags=("texts", "log_clear"))
        self.bg_canvas.tag_bind("log_clear", "<Button-1>", lambda e: self._clear_log())

    def _bind_keys(self) -> None:
        self.bind("<Control-l>", lambda _e: self._clear_log())
        self.bind("<Control-q>", lambda _e: self._quit())
        self.bind("<Escape>",    lambda _e: self._quit())

    def _start_pump(self) -> None:
        def pump():
            for level, msg, tag in self._bus.drain():
                self._append_log(level, msg, tag)
            self._tick_id = self.after(80, pump)
        self._tick_id = self.after(80, pump)

    def _append_log(self, level: str, msg: str, tag: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = self.LEVEL_TAG_TEXT.get(level, "    ")
        line = f"{ts}  {prefix}  {msg}"
        if tag: line += f"   [{tag}]"
        line += "\n"
        self._text.configure(state="normal")
        self._text.insert("end", line, level)
        self._text.configure(state="disabled")
        if self._auto_scroll_var.get(): self._text.see("end")

    def log_info(self, msg, tag=""):  self._bus.info(msg, tag)
    def log_ok(self, msg, tag=""):    self._bus.ok(msg, tag)
    def log_warn(self, msg, tag=""):  self._bus.warn(msg, tag)
    def log_err(self, msg, tag=""):   self._bus.err(msg, tag)
    def log_debug(self, msg, tag=""): self._bus.debug(msg, tag)

    def set_status(self, text: str, color: str = FG_MUTED) -> None: 
        self.after(0, lambda: self.bg_canvas.itemconfig(self._status_pills["status_val"], text=text, fill=color))
    
    def set_app(self, text: str, color: str = FG_MUTED) -> None: 
        display_text = text if len(text) <= 15 else text[:12] + "..."
        self.after(0, lambda: self.bg_canvas.itemconfig(self._status_pills["app_val"], text=display_text, fill=color))
        
    def set_depots(self, text: str, color: str = FG_MUTED) -> None: 
        self.after(0, lambda: self.bg_canvas.itemconfig(self._status_pills["dep_val"], text=text, fill=color))
    
    def set_progress(self, frac: float) -> None:
        v = max(0.0, min(1.0, frac)) * 100
        self.after(0, lambda: self.progress.configure(value=v))

    def set_busy(self, busy: bool) -> None:
        self._busy = busy
        state = "disabled" if busy else "normal"
        self.after(0, lambda: self.entry.configure(state=state))
        self.set_status("busy" if busy else "idle", WARN if busy else FG_MUTED)

    def _fetch_app_name(self, app_id: str):
        try:
            url = f"https://store.steampowered.com/api/appdetails?appids={app_id}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                if str(app_id) in data and data[str(app_id)]["success"]:
                    name = data[str(app_id)]["data"]["name"]
                    self.set_app(name, FG_TEXT)
                    self.log_info(f"Resolved name: {name}", tag="api")
                    return name
        except Exception: pass
        return None

    def _submit(self) -> None:
        if self._busy: return
        raw = self.entry_var.get().strip()
        if not raw: self.log_warn("Empty App ID.", tag="input"); return
        if not raw.isdigit(): self.log_err(f"Invalid App ID: {raw!r}", tag="input"); return
        self.log_ok(f"Queued App ID: {raw}", tag="input")
        self.entry_var.set("")
        self.set_app(raw, ACCENT)
        threading.Thread(target=self._fetch_app_name, args=(raw,), daemon=True).start()
        if self._on_submit is None:
            threading.Thread(target=self._stub_pipeline, args=(raw,), daemon=True).start()
        else:
            threading.Thread(target=self._wrap_callback, args=(raw,), daemon=True).start()

    def _wrap_callback(self, app_id: str) -> None:
        try:
            assert self._on_submit is not None
            self._on_submit(app_id)
        except Exception as e:
            self.log_err(f"Pipeline error: {e}", tag="fatal")
            self.set_busy(False)

    def _stub_pipeline(self, app_id: str) -> None:
        self.set_busy(True)
        try:
            self.log_info(f"Fetching metadata for App ID {app_id}...", tag="stub")
            for i in range(1, 5):
                time.sleep(0.35)
                self.set_progress(i / 5)
                self.log_debug(f"Step {i}/5...", tag="pipeline")
            self.set_progress(1.0)
            self.log_ok("Stub pipeline completed.", tag="stub")
        finally:
            self.set_busy(False)
            self.after(400, lambda: self.set_progress(0))

    def _clear(self) -> None:
        self.entry_var.set("")
        self._clear_log()
        self.set_progress(0)
        self.log_info("UI cleared.", tag="ui")

    def _clear_log(self) -> None:
        self._text.configure(state="normal")
        self._text.delete("1.0", "end")
        self._text.configure(state="disabled")

    def _quit(self) -> None:
        if self._tick_id:
            try: self.after_cancel(self._tick_id)
            except Exception: pass
        self.destroy()