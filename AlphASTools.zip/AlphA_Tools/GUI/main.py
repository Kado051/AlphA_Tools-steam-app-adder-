"""
main.py — Entry point for Steam App Adder.
"""

import sys
from pathlib import Path

# Projenin ana dizinini (AlphA_Tools) Python yoluna ekle
_BASE_DIR = Path(__file__).parent.resolve()
if str(_BASE_DIR) not in sys.path:
    sys.path.insert(0, str(_BASE_DIR))

# Artık core ve GUI klasörleri birer paket (package) olduğu için nokta (.) ile import ediyoruz
from GUI import gui
from core import pipeline

def main():
    # GUI'yi başlat (başlangıçta callback olmadan)
    app = gui.SteamAppAdderGUI(on_submit=None)
    
    # Pipeline'ı GUI'ye bağla
    app._on_submit = lambda app_id: pipeline.handle_app(app_id, gui=app)
    
    # Uygulamayı çalıştır
    app.mainloop()

if __name__ == "__main__":
    main()